// --- PRODUCT DATA (mix of your real products + extend easily) ---
const PRODUCTS = [
  {
    id: 1,
    name: "Royal Black & Gold Silk Saree",
    category: "Sarees",
    price: 4500,
    originalPrice: 6500,
    rating: 4.8,
    reviews: 124,
    image:
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800",
    description:
      "Exquisite silk saree with intricate gold zari work, perfect for weddings and festive occasions.",
    sizes: ["Free Size"],
    isBestSeller: true,
  },
  {
    id: 2,
    name: "Embroidered Anarkali Kurti",
    category: "Kurtis",
    price: 1899,
    originalPrice: 2499,
    rating: 4.5,
    reviews: 89,
    image:
      "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?auto=format&fit=crop&q=80&w=800",
    description:
      "Floor-length Anarkali kurti featuring delicate embroidery and breathable cotton fabric.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    isBestSeller: true,
  },
  {
    id: 3,
    name: "Contemporary Floral Maxi Dress",
    category: "Dresses",
    price: 2200,
    originalPrice: 2999,
    rating: 4.7,
    reviews: 56,
    image:
      "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&q=80&w=800",
    description:
      "A breezy floral maxi dress designed for summer elegance and comfort.",
    sizes: ["XS", "S", "M", "L"],
    isBestSeller: false,
  },
  {
    id: 4,
    name: "Golden Temple Jewellery Set",
    category: "Accessories",
    price: 1200,
    originalPrice: 1800,
    rating: 4.2,
    reviews: 34,
    image:
      "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80&w=800",
    description:
      "Traditional temple jewellery set including necklace and earrings.",
    sizes: ["One Size"],
    isBestSeller: false,
  },
  // Placeholder examples – you can change images/names later
  {
    id: 5,
    name: "Velvet Party Wear Suit",
    category: "Ethnic Wear",
    price: 3500,
    originalPrice: 5000,
    rating: 4.9,
    reviews: 210,
    image:
      "https://images.unsplash.com/photo-1583391733956-6c78276477e2?auto=format&fit=crop&q=80&w=800",
    description:
      "Luxurious velvet suit with sequins work, perfect for reception nights.",
    sizes: ["M", "L", "XL"],
    isBestSeller: true,
  },
  {
    id: 6,
    name: "Chic Office Wear Blazer",
    category: "Western Wear",
    price: 2800,
    originalPrice: 3500,
    rating: 4.4,
    reviews: 45,
    image:
      "https://images.unsplash.com/photo-1548624149-f9b1859aa2d0?auto=format&fit=crop&q=80&w=800",
    description: "Structured blazer for the modern professional woman.",
    sizes: ["S", "M", "L", "XL"],
    isBestSeller: false,
  },
];

function getCart() {
  try {
    return JSON.parse(localStorage.getItem("pf_cart") || "[]");
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem("pf_cart", JSON.stringify(cart));
}

function formatPrice(val) {
  return "₹" + val.toLocaleString("en-IN");
}

function updateCartBadges() {
  const cart = getCart();
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const ids = [
    "cart-count-home",
    "cart-count-shop",
    "cart-count-product",
  ];
  ids.forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (count > 0) {
      el.textContent = count;
      el.classList.remove("hidden");
      el.classList.add("flex");
    } else {
      el.classList.add("hidden");
    }
  });
}

function addToCart(productId, size) {
  const product = PRODUCTS.find((p) => p.id === productId);
  if (!product) return;

  const cart = getCart();
  const keySize = size || (product.sizes && product.sizes[0]) || "Free Size";
  const existing = cart.find(
    (item) => item.id === product.id && item.size === keySize
  );

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: keySize,
      quantity: 1,
      category: product.category,
    });
  }

  saveCart(cart);
  updateCartBadges();
  alert("Added to cart");
}

// --- PRODUCT CARD RENDERING FOR SHOP/HOME ---

function createProductCardHTML(product) {
  return `
    <a href="product.html?id=${product.id}" class="group block bg-white">
      <div class="relative overflow-hidden aspect-[3/4] mb-3">
        <img src="${product.image}" alt="${product.name}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
        ${
          product.isBestSeller
            ? '<span class="absolute top-2 left-2 text-[10px] px-2 py-1 bg-black text-white tracking-wide uppercase">Best Seller</span>'
            : ""
        }
      </div>
      <p class="text-[11px] uppercase tracking-wide text-zinc-500 mb-1">${
        product.category
      }</p>
      <h3 class="text-sm font-medium line-clamp-2 group-hover:text-amber-600">${
        product.name
      }</h3>
      <div class="mt-1 flex items-baseline gap-2">
        <span class="font-semibold text-sm">${formatPrice(product.price)}</span>
        ${
          product.originalPrice && product.originalPrice > product.price
            ? `<span class="text-[11px] line-through text-zinc-400">${formatPrice(
                product.originalPrice
              )}</span>`
            : ""
        }
      </div>
      <div class="mt-1 text-[11px] text-amber-600">
        ★ ${product.rating.toFixed(1)} · ${product.reviews} reviews
      </div>
    </a>
  `;
}

// --- PAGE INITIALISERS ---

function initMobileMenu() {
  const btn = document.getElementById("mobile-menu-toggle");
  const menu = document.getElementById("mobile-menu");
  if (!btn || !menu) return;
  btn.addEventListener("click", () => {
    menu.classList.toggle("hidden");
  });
}

function initHomePage() {
  initMobileMenu();
  updateCartBadges();

  const trendingContainer = document.getElementById("trending-grid");
  if (trendingContainer) {
    const trending = PRODUCTS.filter((p) => p.isBestSeller).slice(0, 4);
    trendingContainer.innerHTML = trending.map(createProductCardHTML).join("");
  }
}

function getURLParam(name) {
  const url = new URL(window.location.href);
  return url.searchParams.get(name);
}

function initShopPage() {
  initMobileMenu();
  updateCartBadges();

  const searchInput = document.getElementById("search-shop");
  const grid = document.getElementById("products-grid");
  const resultsCount = document.getElementById("results-count");
  const sortSelect = document.getElementById("sort-select");
  const filterButtons = document.querySelectorAll(".filter-btn");

  let activeCategory = "all";
  const categoryFromURL = getURLParam("category");
  if (categoryFromURL) activeCategory = categoryFromURL;

  function applyFilterAndRender() {
    let list = [...PRODUCTS];

    if (activeCategory !== "all") {
      list = list.filter((p) => p.category === activeCategory);
    }

    const q = (searchInput?.value || "").toLowerCase().trim();
    if (q) {
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }

    const sortVal = sortSelect?.value;
    if (sortVal === "low-high") {
      list.sort((a, b) => a.price - b.price);
    } else if (sortVal === "high-low") {
      list.sort((a, b) => b.price - a.price);
    }

    if (grid) {
      if (!list.length) {
        grid.innerHTML =
          '<p class="text-sm text-zinc-500 col-span-full">No products found.</p>';
      } else {
        grid.innerHTML = list.map(createProductCardHTML).join("");
      }
    }

    if (resultsCount) {
      resultsCount.textContent = `Showing ${list.length} product${
        list.length !== 1 ? "s" : ""
      }`;
    }
  }

  // Activate category from URL if present
  filterButtons.forEach((btn) => {
    const cat = btn.dataset.category;
    if (cat === activeCategory) {
      btn.classList.add("text-amber-600", "font-semibold");
    }
  });

  filterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterButtons.forEach((b) =>
        b.classList.remove("text-amber-600", "font-semibold")
      );
      btn.classList.add("text-amber-600", "font-semibold");
      activeCategory = btn.dataset.category;
      applyFilterAndRender();
    });
  });

  searchInput?.addEventListener("input", applyFilterAndRender);
  sortSelect?.addEventListener("change", applyFilterAndRender);

  applyFilterAndRender();
}

function initProductPage() {
  initMobileMenu();
  updateCartBadges();

  const container = document.getElementById("product-details");
  const id = parseInt(getURLParam("id"), 10);
  const product = PRODUCTS.find((p) => p.id === id);

  if (!container) return;

  if (!product) {
    container.innerHTML =
      '<p class="text-sm text-zinc-500 mt-4">Product not found.</p>';
    return;
  }

  const defaultSize =
    (product.sizes && product.sizes.length && product.sizes[0]) || "Free Size";

  container.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
      <div>
        <div class="aspect-[3/4] bg-zinc-100 overflow-hidden">
          <img src="${product.image}" alt="${product.name}" class="w-full h-full object-cover" />
        </div>
      </div>

      <div>
        <p class="text-xs tracking-[0.25em] uppercase text-amber-600 mb-1">${
          product.category
        }</p>
        <h1 class="text-3xl font-serif mb-3">${product.name}</h1>

        <div class="flex items-center gap-4 mb-4">
          <span class="text-xl font-semibold">${formatPrice(product.price)}</span>
          ${
            product.originalPrice && product.originalPrice > product.price
              ? `<span class="text-xs line-through text-zinc-400">${formatPrice(
                  product.originalPrice
                )}</span>`
              : ""
          }
        </div>

        <div class="text-xs text-amber-600 mb-4">
          ★ ${product.rating.toFixed(1)} · ${product.reviews} reviews
        </div>

        <p class="text-sm text-zinc-700 mb-6">
          ${product.description}
        </p>

        <div class="mb-6">
          <p class="text-xs font-semibold tracking-wide mb-2 uppercase">Select Size</p>
          <div id="size-wrapper" class="flex flex-wrap gap-2">
            ${product.sizes
              .map(
                (s) => `
              <button data-size="${s}" class="size-pill ${
                  s === defaultSize
                    ? "bg-black text-white"
                    : "border border-zinc-300"
                } text-xs px-4 py-2 uppercase tracking-wide">
                ${s}
              </button>`
              )
              .join("")}
          </div>
        </div>

        <button
          id="add-to-cart-btn"
          class="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3 bg-black text-white text-xs uppercase tracking-wide hover:bg-zinc-800"
        >
          Add to Cart
        </button>
      </div>
    </div>
  `;

  let selectedSize = defaultSize;
  const sizeButtons = container.querySelectorAll(".size-pill");
  sizeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      sizeButtons.forEach((b) =>
        b.classList.remove("bg-black", "text-white")
      );
      btn.classList.add("bg-black", "text-white");
      selectedSize = btn.dataset.size;
    });
  });

  const addBtn = document.getElementById("add-to-cart-btn");
  addBtn?.addEventListener("click", () => {
    addToCart(product.id, selectedSize);
  });
}

function initCartPage() {
  initMobileMenu();
  updateCartBadges();

  const container = document.getElementById("cart-content");
  if (!container) return;

  let cart = getCart();

  function render() {
    cart = getCart();
    if (!cart.length) {
      container.innerHTML = `
        <div class="text-center py-16">
          <p class="text-sm text-zinc-500 mb-4">Your cart is empty.</p>
          <a href="shop.html" class="inline-flex px-6 py-2 border border-zinc-300 text-xs uppercase tracking-wide hover:border-black">
            Continue Shopping
          </a>
        </div>
      `;
      return;
    }

    const subtotal = cart.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
    const gst = Math.round(subtotal * 0.18);
    const total = subtotal + gst;

    container.innerHTML = `
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div class="lg:col-span-2 space-y-5">
          ${cart
            .map(
              (item, idx) => `
            <div class="flex gap-4 border-b border-zinc-100 pb-5">
              <div class="w-24 h-32 bg-zinc-100 flex-shrink-0 overflow-hidden">
                <img src="${item.image}" alt="${
                item.name
              }" class="w-full h-full object-cover" />
              </div>
              <div class="flex-1 text-sm">
                <div class="flex justify-between mb-1">
                  <p class="font-medium">${item.name}</p>
                  <button data-index="${idx}" class="remove-item text-[11px] text-zinc-400 hover:text-red-500">
                    Remove
                  </button>
                </div>
                <p class="text-[11px] text-zinc-500 mb-2">
                  Size: ${item.size} · ${item.category}
                </p>
                <div class="flex items-center justify-between mt-3">
                  <div class="flex items-center border border-zinc-300 text-xs">
                    <button data-index="${idx}" data-action="dec" class="qty-btn px-3 py-1 hover:bg-zinc-100">-</button>
                    <span class="px-3 py-1">${item.quantity}</span>
                    <button data-index="${idx}" data-action="inc" class="qty-btn px-3 py-1 hover:bg-zinc-100">+</button>
                  </div>
                  <span class="font-semibold">${formatPrice(
                    item.price * item.quantity
                  )}</span>
                </div>
              </div>
            </div>
          `
            )
            .join("")}
        </div>

        <div class="bg-zinc-50 p-6 text-sm">
          <h2 class="font-semibold mb-4">Order Summary</h2>
          <div class="space-y-2 mb-4">
            <div class="flex justify-between">
              <span class="text-zinc-600">Subtotal</span>
              <span>${formatPrice(subtotal)}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-zinc-600">Shipping</span>
              <span class="text-green-600">Free</span>
            </div>
            <div class="flex justify-between">
              <span class="text-zinc-600">GST (18%)</span>
              <span>${formatPrice(gst)}</span>
            </div>
          </div>
          <div class="flex justify-between font-semibold text-base mb-5">
            <span>Total</span>
            <span>${formatPrice(total)}</span>
          </div>
          <a href="checkout.html" class="block w-full text-center px-6 py-2 bg-black text-white text-xs uppercase tracking-wide hover:bg-zinc-800">
            Proceed to Checkout
          </a>
        </div>
      </div>
    `;

    // Attach qty + remove handlers
    container.querySelectorAll(".qty-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const index = parseInt(btn.dataset.index, 10);
        const action = btn.dataset.action;
        const current = cart[index];
        if (!current) return;
        if (action === "inc") current.quantity += 1;
        if (action === "dec") current.quantity = Math.max(1, current.quantity - 1);
        saveCart(cart);
        updateCartBadges();
        render();
      });
    });

    container.querySelectorAll(".remove-item").forEach((btn) => {
      btn.addEventListener("click", () => {
        const index = parseInt(btn.dataset.index, 10);
        cart.splice(index, 1);
        saveCart(cart);
        updateCartBadges();
        render();
      });
    });
  }

  render();
}

function initCheckoutPage() {
  initMobileMenu();
  updateCartBadges();

  const wrap = document.getElementById("checkout-wrapper");
  if (!wrap) return;

  const cart = getCart();
  if (!cart.length) {
    wrap.innerHTML = `
      <div class="text-center py-16 text-sm">
        <p class="text-zinc-500 mb-4">Your cart is empty.</p>
        <a href="shop.html" class="inline-flex px-6 py-2 border border-zinc-300 text-xs uppercase tracking-wide hover:border-black">
          Browse Products
        </a>
      </div>
    `;
    return;
  }

  const subtotal = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  const gst = Math.round(subtotal * 0.18);
  const total = subtotal + gst;

  wrap.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-2 gap-10 text-sm">
      <form id="checkout-form" class="space-y-4">
        <h2 class="font-serif text-xl mb-2">Shipping Details</h2>
        <div class="grid grid-cols-2 gap-3">
          <input required name="firstName" type="text" placeholder="First Name" class="border border-zinc-300 px-3 py-2 outline-none focus:border-black" />
          <input required name="lastName" type="text" placeholder="Last Name" class="border border-zinc-300 px-3 py-2 outline-none focus:border-black" />
        </div>
        <input required name="email" type="email" placeholder="Email Address" class="border border-zinc-300 px-3 py-2 outline-none focus:border-black w-full" />
        <input required name="phone" type="tel" placeholder="Phone Number" class="border border-zinc-300 px-3 py-2 outline-none focus:border-black w-full" />
        <input required name="address" type="text" placeholder="Full Address" class="border border-zinc-300 px-3 py-2 outline-none focus:border-black w-full" />
        <div class="grid grid-cols-2 gap-3">
          <input required name="city" type="text" placeholder="City" class="border border-zinc-300 px-3 py-2 outline-none focus:border-black" />
          <input required name="pincode" type="text" placeholder="Pincode" class="border border-zinc-300 px-3 py-2 outline-none focus:border-black" />
        </div>

        <h2 class="font-serif text-xl mt-6 mb-2">Payment</h2>
        <div class="space-y-2">
          <label class="flex items-center gap-2 border border-zinc-300 px-3 py-2 cursor-pointer">
            <input type="radio" name="payment" value="upi" class="accent-black" />
            <span>UPI (GPay / PhonePe / Paytm)</span>
          </label>
          <label class="flex items-center gap-2 border border-zinc-300 px-3 py-2 cursor-pointer">
            <input type="radio" name="payment" value="card" class="accent-black" />
            <span>Credit / Debit Card</span>
          </label>
          <label class="flex items-center gap-2 border border-zinc-300 px-3 py-2 cursor-pointer">
            <input type="radio" name="payment" value="cod" class="accent-black" checked />
            <span>Cash on Delivery (COD)</span>
          </label>
        </div>

        <button class="mt-6 w-full px-6 py-2 bg-black text-white text-xs uppercase tracking-wide hover:bg-zinc-800">
          Place Order
        </button>
      </form>

      <aside class="bg-zinc-50 p-6">
        <h2 class="font-semibold mb-3">Order Summary</h2>
        <div class="space-y-2 mb-4 text-xs">
          ${cart
            .map(
              (item) => `
            <div class="flex justify-between">
              <span>${item.name} (x${item.quantity})</span>
              <span>${formatPrice(item.price * item.quantity)}</span>
            </div>
          `
            )
            .join("")}
        </div>
        <div class="space-y-2 mb-4 text-sm">
          <div class="flex justify-between">
            <span class="text-zinc-600">Subtotal</span>
            <span>${formatPrice(subtotal)}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-zinc-600">Shipping</span>
            <span class="text-green-600">Free</span>
          </div>
          <div class="flex justify-between">
            <span class="text-zinc-600">GST (18%)</span>
            <span>${formatPrice(gst)}</span>
          </div>
        </div>
        <div class="flex justify-between font-semibold text-base mb-4">
          <span>Total</span>
          <span>${formatPrice(total)}</span>
        </div>
        <p class="text-[11px] text-zinc-500">
          This is a demo checkout for Parinidhi Fashion. You can connect Razorpay / Stripe or any Indian gateway later.
        </p>
      </aside>
    </div>
  `;

  const form = document.getElementById("checkout-form");
  form?.addEventListener("submit", (e) => {
    e.preventDefault();
    // fake success
    localStorage.removeItem("pf_cart");
    updateCartBadges();
    wrap.innerHTML = `
      <div class="text-center py-16 max-w-md mx-auto">
        <p class="text-3xl mb-4">Thank you ♡</p>
        <p class="text-sm text-zinc-600 mb-6">
          Your order has been placed. You’ll receive a confirmation on your email & WhatsApp shortly.
        </p>
        <a href="shop.html" class="inline-flex px-6 py-2 border border-zinc-300 text-xs uppercase tracking-wide hover:border-black">
          Continue Shopping
        </a>
      </div>
    `;
  });
}

// --- ENTRY POINT ---
document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;

  if (page === "home") initHomePage();
  if (page === "shop") initShopPage();
  if (page === "product") initProductPage();
  if (page === "cart") initCartPage();
  if (page === "checkout") initCheckoutPage();
  if (page === "contact") {
    initMobileMenu();
    updateCartBadges();
  }
});
